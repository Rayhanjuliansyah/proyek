import axios from "axios";

// Membuat instance Axios
const axiosInstance = axios.create({
    baseURL: "http://localhost:3001/api",
    timeout: 10000, // Waktu tunggu permintaan dalam milidetik
});

// Menambahkan interceptor request
axiosInstance.interceptors.request.use((config) => {
    const user = localStorage.getItem("user");
    const token = user ? JSON.parse(user).token : "";
    config.headers.Authorization = `Bearer ${token}`; // Menggunakan backtick
    return config;
}, (error) => {
    // Menangani kesalahan sebelum permintaan dikirim
    return Promise.reject(error);
});

// Menambahkan interceptor response
axiosInstance.interceptors.response.use(
    (response) => {
        // Menangani respons yang berhasil
        return response;
    },
    (error) => {
        // Menangani kesalahan respons
        if (error.response && error.response.status === 401) {
            console.error("Unauthorized! Redirecting to login.");
            // Lakukan sesuatu, seperti logout pengguna
        }
        return Promise.reject(error);
    }
);

export default axiosInstance;
