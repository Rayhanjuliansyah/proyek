/*
  Warnings:

  - You are about to drop the column `rating` on the `ustad` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "ustad" DROP COLUMN "rating";
