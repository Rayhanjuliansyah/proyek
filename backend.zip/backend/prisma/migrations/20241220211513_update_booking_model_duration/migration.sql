-- AlterTable
ALTER TABLE "booking" ALTER COLUMN "duration" SET DATA TYPE TEXT;
